import HeroSection from "./components/HeroSection";

export default function App() {
  return (
    <main className="min-h-screen" style={{ backgroundColor: "#f5f5f5" }}>
      <HeroSection />
    </main>
  );
}
