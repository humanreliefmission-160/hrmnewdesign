import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Heart,
  Utensils,
  Droplets,
  Building2,
  GraduationCap,
  TrendingUp,
  ChevronRight,
  X,
  Sparkles,
} from "lucide-react";

const BRAND = {
  purple: "#650199",
  yellow: "#ffd21b",
  white: "#f5f5f5",
  black: "#1a1a1a",
};

interface Project {
  icon: React.ReactNode;
  name: string;
  desc: string;
}

interface Phase {
  id: number;
  label: string;
  subtitle: string;
  color: string;
  textColor: string;
  glowColor: string;
  projects: Project[];
  description: string;
  badge: string;
}

const phases: Phase[] = [
  {
    id: 1,
    label: "Essentials",
    subtitle: "Phase 1",
    color: BRAND.purple,
    textColor: BRAND.white,
    glowColor: `${BRAND.purple}55`,
    badge: "Survive",
    description:
      "Provide the bare necessities to keep people alive and safe — immediate relief before anything else can begin.",
    projects: [
      { icon: <Heart size={13} />, name: "Healthcare", desc: "Emergency medical care & clinics" },
      { icon: <Utensils size={13} />, name: "Food Aid", desc: "Nutritious meals & food baskets" },
    ],
  },
  {
    id: 2,
    label: "Stability",
    subtitle: "Phase 2",
    color: BRAND.yellow,
    textColor: BRAND.black,
    glowColor: `${BRAND.yellow}88`,
    badge: "Stabilise",
    description:
      "Build stable foundations so families can live safely with clean water and proper infrastructure in place.",
    projects: [
      { icon: <Droplets size={13} />, name: "Water Aid", desc: "Clean water access & sanitation" },
      { icon: <Building2 size={13} />, name: "Infrastructure", desc: "Housing, roads & community assets" },
    ],
  },
  {
    id: 3,
    label: "Development",
    subtitle: "Phase 3",
    color: BRAND.purple,
    textColor: BRAND.white,
    glowColor: `${BRAND.purple}55`,
    badge: "Grow",
    description:
      "Invest in people through education and sponsorships to unlock their potential, skills, and capabilities.",
    projects: [
      { icon: <GraduationCap size={13} />, name: "Sponsorships", desc: "Education & vocational training" },
    ],
  },
  {
    id: 4,
    label: "Sustainability",
    subtitle: "Phase 4",
    color: BRAND.black,
    textColor: BRAND.white,
    glowColor: `rgba(26,26,26,0.4)`,
    badge: "Thrive",
    description:
      "Generate sustainable income so individuals become self-sufficient — and eventually Zakat payers themselves.",
    projects: [
      { icon: <TrendingUp size={13} />, name: "Income Generation", desc: "Businesses, jobs & financial growth" },
    ],
  },
];

// Card positions in 520×520 SVG space
// P1 top-left, P2 top-right, P3 bottom-left, P4 bottom-right
// Card centers approximately:
const CARD_CENTERS = [
  { cx: 130, cy: 130 }, // P1
  { cx: 390, cy: 130 }, // P2
  { cx: 130, cy: 390 }, // P3
  { cx: 390, cy: 390 }, // P4
];
const HUB_CENTER = { cx: 260, cy: 260 };

interface EcosystemDiagramProps {
  isInView: boolean;
}

export default function EcosystemDiagram({ isInView }: EcosystemDiagramProps) {
  const [activePhase, setActivePhase] = useState<number | null>(null);
  const [hovered, setHovered] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handlePhaseClick = (id: number) => {
    setActivePhase((prev) => (prev === id ? null : id));
  };

  return (
    <div className="relative w-full" style={{ maxWidth: 560 }}>
      {/* ── Zakat Transformation Badge ── */}
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.9 }}
        animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
        transition={{ duration: 0.55, delay: 0.5, type: "spring", stiffness: 200 }}
        className="flex items-center justify-center mb-3"
      >
        <div
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full shadow-xl cursor-pointer"
          style={{
            backgroundColor: BRAND.black,
            color: BRAND.white,
            border: `2.5px solid ${BRAND.yellow}`,
            boxShadow: `0 4px 24px ${BRAND.yellow}44`,
          }}
        >
          <Sparkles size={12} style={{ color: BRAND.yellow }} />
          <span className="text-[11px] font-bold tracking-widest uppercase">
            Zakat Transformation Journey
          </span>
          <motion.span
            className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider"
            style={{ backgroundColor: BRAND.yellow, color: BRAND.black }}
            animate={{ scale: [1, 1.08, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            4 PHASES
          </motion.span>
        </div>
      </motion.div>

      {/* ── Main Diagram ── */}
      <div
        ref={containerRef}
        className="relative"
        style={{ width: "100%", aspectRatio: "1 / 1" }}
      >
        {/* SVG Connector Lines layer */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none"
          viewBox="0 0 520 520"
          preserveAspectRatio="xMidYMid meet"
          style={{ zIndex: 1 }}
        >
          <defs>
            <linearGradient id="lg1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={BRAND.purple} />
              <stop offset="100%" stopColor={BRAND.yellow} />
            </linearGradient>
            <linearGradient id="lg2" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor={BRAND.yellow} />
              <stop offset="100%" stopColor={BRAND.purple} />
            </linearGradient>
            <linearGradient id="lg3" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor={BRAND.purple} />
              <stop offset="100%" stopColor={BRAND.black} />
            </linearGradient>
            <linearGradient id="lg4" x1="100%" y1="100%" x2="0%" y2="0%">
              <stop offset="0%" stopColor={BRAND.black} />
              <stop offset="100%" stopColor={BRAND.yellow} />
            </linearGradient>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="4" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
            <filter id="glowStrong" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="7" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Lines: card center → hub center */}
          {CARD_CENTERS.map((pos, i) => {
            const phase = phases[i];
            const isActive = activePhase === phase.id || hovered === phase.id;
            const gradId = ["lg1", "lg2", "lg3", "lg4"][i];
            const lineLength = Math.sqrt(
              Math.pow(HUB_CENTER.cx - pos.cx, 2) + Math.pow(HUB_CENTER.cy - pos.cy, 2)
            );
            return (
              <motion.line
                key={`line-${phase.id}`}
                x1={pos.cx}
                y1={pos.cy}
                x2={HUB_CENTER.cx}
                y2={HUB_CENTER.cy}
                stroke={`url(#${gradId})`}
                strokeWidth={isActive ? 3.5 : 2}
                strokeDasharray={lineLength}
                strokeLinecap="round"
                filter={isActive ? "url(#glowStrong)" : undefined}
                initial={{ strokeDashoffset: lineLength, opacity: 0 }}
                animate={
                  isInView
                    ? {
                        strokeDashoffset: 0,
                        opacity: isActive ? 1 : activePhase !== null ? 0.2 : 0.5,
                      }
                    : { strokeDashoffset: lineLength, opacity: 0 }
                }
                transition={{ duration: 1.1, delay: 0.5 + i * 0.18, ease: "easeInOut" }}
              />
            );
          })}

          {/* Traveling dots */}
          {isInView &&
            CARD_CENTERS.map((pos, i) => (
              <TravelingDot
                key={`dot-${i}`}
                x1={pos.cx}
                y1={pos.cy}
                x2={HUB_CENTER.cx}
                y2={HUB_CENTER.cy}
                delay={1.6 + i * 0.5}
                color={[BRAND.purple, BRAND.yellow, BRAND.purple, BRAND.black][i]}
              />
            ))}
        </svg>

        {/* Center Hub */}
        <motion.div
          className="absolute flex flex-col items-center justify-center rounded-full cursor-pointer select-none"
          style={{
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            zIndex: 10,
            width: "16%",
            height: "16%",
            minWidth: 64,
            minHeight: 64,
            backgroundColor: BRAND.purple,
            border: `3px solid ${BRAND.yellow}`,
            boxShadow: `0 0 0 10px ${BRAND.purple}18, 0 0 40px ${BRAND.purple}55`,
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.5, delay: 1.15, type: "spring", stiffness: 220 }}
          whileHover={{
            scale: 1.12,
            boxShadow: `0 0 0 18px ${BRAND.purple}28, 0 0 60px ${BRAND.purple}80`,
          }}
          whileTap={{ scale: 0.94 }}
        >
          <span
            className="text-[9px] sm:text-[10px] font-black tracking-widest uppercase leading-none"
            style={{ color: BRAND.yellow }}
          >
            ZAKAT
          </span>
          <span
            className="text-[7px] sm:text-[9px] font-bold mt-0.5 text-center leading-tight px-1"
            style={{ color: BRAND.white }}
          >
            Hub
          </span>

          {/* Pulse rings */}
          {[0, 1].map((j) => (
            <motion.div
              key={j}
              className="absolute inset-0 rounded-full pointer-events-none"
              style={{
                border: `2px solid ${j === 0 ? BRAND.purple : BRAND.yellow}`,
              }}
              animate={{
                scale: [1, 1.6 + j * 0.4, 1],
                opacity: [0.45, 0, 0.45],
              }}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: j * 0.9,
              }}
            />
          ))}
        </motion.div>

        {/* Phase Cards — 4 corners */}
        {phases.map((phase, idx) => (
          <PhaseCard
            key={phase.id}
            phase={phase}
            idx={idx}
            isInView={isInView}
            isActive={activePhase === phase.id}
            isHovered={hovered === phase.id}
            anyActive={activePhase !== null}
            onHover={setHovered}
            onClick={handlePhaseClick}
          />
        ))}
      </div>

      {/* Phase Detail Drawer */}
      <AnimatePresence>
        {activePhase !== null && (
          <PhaseDetailPanel
            phase={phases[activePhase - 1]}
            onClose={() => setActivePhase(null)}
          />
        )}
      </AnimatePresence>

      {/* Journey progression bar */}
      <motion.div
        className="flex items-center justify-between mt-4 px-2"
        initial={{ opacity: 0 }}
        animate={isInView ? { opacity: 1 } : {}}
        transition={{ duration: 0.6, delay: 1.4 }}
      >
        <span className="text-[11px] font-semibold" style={{ color: `${BRAND.black}60` }}>
          Zakat Receiver
        </span>
        <div className="flex items-center gap-1.5 mx-3 flex-1">
          {phases.map((ph, i) => (
            <div key={ph.id} className="flex items-center flex-1">
              <motion.div
                className="h-1.5 rounded-full flex-1 cursor-pointer"
                style={{ backgroundColor: ph.color === BRAND.yellow ? BRAND.yellow : ph.color }}
                whileHover={{ scaleY: 2, opacity: 1 }}
                animate={{
                  opacity: [0.5, 1, 0.5],
                }}
                transition={{
                  opacity: { duration: 2, repeat: Infinity, delay: i * 0.4 },
                }}
                onClick={() => handlePhaseClick(ph.id)}
                title={ph.label}
              />
              {i < 3 && (
                <div
                  className="w-1.5 h-1.5 rounded-full mx-0.5 flex-shrink-0"
                  style={{ backgroundColor: BRAND.black, opacity: 0.2 }}
                />
              )}
            </div>
          ))}
        </div>
        <span
          className="text-[11px] font-extrabold whitespace-nowrap"
          style={{ color: BRAND.purple }}
        >
          Zakat Payer ✦
        </span>
      </motion.div>
    </div>
  );
}

/* ─────────────────────────────────────────
   Traveling animated dot along a line
───────────────────────────────────────── */
interface TravelingDotProps {
  x1: number; y1: number; x2: number; y2: number;
  delay: number; color: string;
}

function TravelingDot({ x1, y1, x2, y2, delay, color }: TravelingDotProps) {
  return (
    <motion.circle
      r={4}
      fill={color}
      filter="url(#glow)"
      initial={{ cx: x1, cy: y1, opacity: 0 }}
      animate={{
        cx: [x1, x2],
        cy: [y1, y2],
        opacity: [0, 1, 1, 0],
      }}
      transition={{
        duration: 2.2,
        delay,
        repeat: Infinity,
        repeatDelay: 1.8,
        ease: "easeInOut",
      }}
    />
  );
}

/* ─────────────────────────────────────────
   Phase Card
───────────────────────────────────────── */
interface CardPos {
  top?: string;
  left?: string;
  right?: string;
  bottom?: string;
  origin: string;
}
const CARD_POSITIONS: CardPos[] = [
  { top: "1%", left: "1%", origin: "top left" },
  { top: "1%", right: "1%", left: "auto", origin: "top right" },
  { bottom: "1%", left: "1%", top: "auto", origin: "bottom left" },
  { bottom: "1%", right: "1%", left: "auto", top: "auto", origin: "bottom right" },
];

const SLIDE_IN = [
  { x: -40, y: -40 },
  { x: 40, y: -40 },
  { x: -40, y: 40 },
  { x: 40, y: 40 },
];

interface PhaseCardProps {
  phase: Phase;
  idx: number;
  isInView: boolean;
  isActive: boolean;
  isHovered: boolean;
  anyActive: boolean;
  onHover: (id: number | null) => void;
  onClick: (id: number) => void;
}

function PhaseCard({
  phase, idx, isInView, isActive, isHovered, anyActive, onHover, onClick,
}: PhaseCardProps) {
  const pos = CARD_POSITIONS[idx];
  const highlighted = isActive || isHovered;
  const dimmed = anyActive && !isActive && !isHovered;

  return (
    <motion.div
      style={{
        position: "absolute",
        zIndex: 5,
        width: "38%",
        transformOrigin: pos.origin,
        top: pos.top,
        left: pos.left,
        right: pos.right,
        bottom: pos.bottom,
      }}
      initial={{ opacity: 0, ...SLIDE_IN[idx], scale: 0.82 }}
      animate={
        isInView
          ? {
              opacity: dimmed ? 0.45 : 1,
              x: 0,
              y: 0,
              scale: isActive ? 1.04 : 1,
            }
          : {}
      }
      transition={{
        duration: 0.6,
        delay: 0.25 + idx * 0.15,
        type: "spring",
        stiffness: 150,
        damping: 18,
      }}
      whileHover={{ scale: 1.07, zIndex: 20, transition: { duration: 0.2 } }}
      whileTap={{ scale: 0.96 }}
      onHoverStart={() => onHover(phase.id)}
      onHoverEnd={() => onHover(null)}
      onClick={() => onClick(phase.id)}
    >
      <div
        className="relative rounded-2xl p-3 cursor-pointer overflow-hidden transition-all duration-300 select-none"
        style={{
          backgroundColor: "#ffffff",
          border: `2px solid ${highlighted ? phase.color : "rgba(0,0,0,0.06)"}`,
          boxShadow: highlighted
            ? `0 8px 32px ${phase.glowColor}, 0 2px 10px rgba(0,0,0,0.08)`
            : "0 3px 16px rgba(0,0,0,0.08)",
        }}
      >
        {/* Glow background */}
        <motion.div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          style={{ backgroundColor: phase.color }}
          animate={{ opacity: highlighted ? 0.055 : 0 }}
          transition={{ duration: 0.25 }}
        />

        {/* Phase badge */}
        <div
          className="absolute top-[-10px] left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full text-[8px] font-black tracking-widest uppercase whitespace-nowrap z-10"
          style={{
            backgroundColor: phase.color,
            color: phase.textColor,
            boxShadow: highlighted ? `0 4px 14px ${phase.glowColor}` : "none",
          }}
        >
          {phase.subtitle}
        </div>

        {/* Title */}
        <div className="mt-3 mb-1.5 relative z-10">
          <h3
            className="text-xs sm:text-sm font-extrabold leading-tight"
            style={{ color: phase.color }}
          >
            {phase.label}
          </h3>
          <span
            className="inline-block mt-1 px-1.5 py-0.5 rounded-md text-[8px] font-bold uppercase tracking-wider"
            style={{
              backgroundColor:
                phase.color === BRAND.yellow ? BRAND.yellow : `${phase.color}18`,
              color:
                phase.color === BRAND.yellow ? BRAND.black : phase.color,
            }}
          >
            {phase.badge}
          </span>
        </div>

        {/* Projects list */}
        <div className="flex flex-col gap-1 relative z-10">
          {phase.projects.map((p) => (
            <motion.div
              key={p.name}
              className="flex items-center gap-1 text-[9px] sm:text-[10px] font-semibold rounded-lg px-1.5 py-1"
              style={{ color: BRAND.black, backgroundColor: "rgba(0,0,0,0.04)" }}
              whileHover={{
                backgroundColor: `${phase.color}18`,
                color: phase.color,
                x: 3,
                transition: { duration: 0.15 },
              }}
            >
              <span style={{ color: phase.color }}>{p.icon}</span>
              {p.name}
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          className="flex items-center gap-0.5 mt-2 text-[9px] font-bold relative z-10"
          style={{ color: phase.color, opacity: 0.6 }}
          whileHover={{ opacity: 1, x: 2 }}
        >
          View <ChevronRight size={9} />
        </motion.div>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────
   Phase Detail Panel
───────────────────────────────────────── */
function PhaseDetailPanel({ phase, onClose }: { phase: Phase; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.96 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="relative mt-5 rounded-2xl p-5 overflow-hidden"
      style={{
        backgroundColor: "#ffffff",
        border: `2px solid ${phase.color}`,
        boxShadow: `0 12px 48px ${phase.glowColor}`,
      }}
    >
      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at 0% 0%, ${phase.color}14, transparent 65%)`,
        }}
      />

      <div className="relative flex items-start gap-4">
        <div className="flex-1">
          <div className="flex items-center flex-wrap gap-2 mb-3">
            <span
              className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest"
              style={{ backgroundColor: phase.color, color: phase.textColor }}
            >
              {phase.subtitle} · {phase.label}
            </span>
            <span
              className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider"
              style={{
                backgroundColor:
                  phase.color === BRAND.yellow ? BRAND.yellow : `${phase.color}18`,
                color:
                  phase.color === BRAND.yellow ? BRAND.black : phase.color,
              }}
            >
              {phase.badge}
            </span>
          </div>

          <p
            className="text-sm leading-relaxed mb-4"
            style={{ color: `${BRAND.black}88` }}
          >
            {phase.description}
          </p>

          <div className="flex flex-wrap gap-2">
            {phase.projects.map((p) => (
              <motion.div
                key={p.name}
                className="flex items-start gap-2 px-3 py-2 rounded-xl cursor-pointer"
                style={{
                  backgroundColor: `${phase.color}10`,
                  border: `1px solid ${phase.color}30`,
                }}
                whileHover={{
                  backgroundColor: `${phase.color}20`,
                  scale: 1.02,
                }}
              >
                <span
                  className="mt-0.5 flex-shrink-0"
                  style={{ color: phase.color }}
                >
                  {p.icon}
                </span>
                <div>
                  <div
                    className="text-xs font-bold"
                    style={{ color: phase.color }}
                  >
                    {p.name}
                  </div>
                  <div
                    className="text-[10px] mt-0.5"
                    style={{ color: `${BRAND.black}70` }}
                  >
                    {p.desc}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          className="flex-shrink-0 w-7 h-7 flex items-center justify-center rounded-full transition-colors duration-200"
          style={{ backgroundColor: `${BRAND.black}10` }}
        >
          <X size={13} style={{ color: BRAND.black }} />
        </button>
      </div>
    </motion.div>
  );
}
