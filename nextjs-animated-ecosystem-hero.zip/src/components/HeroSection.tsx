import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import {
  Heart,
  Utensils,
  Droplets,
  Building2,
  GraduationCap,
  TrendingUp,
  ArrowRight,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import EcosystemDiagram from "./EcosystemDiagram";

const BRAND = {
  purple: "#650199",
  yellow: "#ffd21b",
  white: "#f5f5f5",
  black: "#1a1a1a",
};

const projects = [
  { icon: <Heart size={13} />, label: "Healthcare" },
  { icon: <Utensils size={13} />, label: "Food Aid" },
  { icon: <Droplets size={13} />, label: "Water Aid" },
  { icon: <Building2 size={13} />, label: "Infrastructure" },
  { icon: <GraduationCap size={13} />, label: "Sponsorships" },
  { icon: <TrendingUp size={13} />, label: "Income Generation" },
];

export default function HeroSection() {
  const ref = useRef<HTMLElement>(null);
  const isInView = useInView(ref, { once: false, margin: "-80px" });

  return (
    <section
      ref={ref}
      className="relative min-h-screen overflow-hidden"
      style={{ backgroundColor: BRAND.white }}
    >
      {/* Dot grid background */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle, ${BRAND.purple}18 1px, transparent 1px)`,
          backgroundSize: "38px 38px",
        }}
      />

      {/* Ambient glow blobs */}
      <div
        className="absolute top-[-100px] left-[-100px] w-[500px] h-[500px] rounded-full blur-[140px] opacity-[0.08] pointer-events-none"
        style={{ backgroundColor: BRAND.purple }}
      />
      <div
        className="absolute bottom-[-80px] right-[5%] w-[400px] h-[400px] rounded-full blur-[120px] opacity-[0.10] pointer-events-none"
        style={{ backgroundColor: BRAND.yellow }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-[1400px] mx-auto px-6 md:px-12 lg:px-16 py-16 md:py-20 lg:py-24 min-h-screen flex items-center">
        <div className="flex flex-col lg:flex-row items-center gap-10 xl:gap-20 w-full">

          {/* ══ LEFT — Text Column ══ */}
          <div className="flex-1 w-full max-w-xl lg:max-w-[500px]">

            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: -18 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.55, ease: "easeOut" }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8 cursor-pointer"
              style={{
                backgroundColor: `${BRAND.purple}14`,
                border: `1.5px solid ${BRAND.purple}35`,
              }}
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.97 }}
            >
              <Sparkles size={13} style={{ color: BRAND.yellow }} />
              <span
                className="text-[11px] font-bold tracking-widest uppercase"
                style={{ color: BRAND.purple }}
              >
                Zakat Transformation Ecosystem
              </span>
              <motion.span
                className="ml-1 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider"
                style={{ backgroundColor: BRAND.yellow, color: BRAND.black }}
                animate={{ scale: [1, 1.06, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                4 PHASES
              </motion.span>
            </motion.div>

            {/* Headline */}
            <motion.h1
              initial={{ opacity: 0, y: 28 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.65, delay: 0.1, ease: "easeOut" }}
              className="text-4xl sm:text-5xl xl:text-[3.6rem] font-extrabold leading-[1.1] tracking-tight mb-6"
              style={{ color: BRAND.black }}
            >
              From{" "}
              <span style={{ color: BRAND.purple }}>Receiving</span>
              <br />
              Zakat to{" "}
              <span className="relative inline-block">
                <span style={{ color: BRAND.purple }}>Paying</span>
                <motion.span
                  initial={{ scaleX: 0 }}
                  animate={isInView ? { scaleX: 1 } : {}}
                  transition={{ duration: 0.7, delay: 0.7, ease: "easeOut" }}
                  className="absolute left-0 bottom-[-5px] h-[4px] w-full rounded-full origin-left block"
                  style={{ backgroundColor: BRAND.yellow }}
                />
              </span>{" "}
              Zakat
            </motion.h1>

            {/* Body */}
            <motion.p
              initial={{ opacity: 0, y: 18 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.65, delay: 0.2, ease: "easeOut" }}
              className="text-base sm:text-lg leading-relaxed mb-9"
              style={{ color: `${BRAND.black}88` }}
            >
              Our 4-phase ecosystem lifts the needy out of poverty — providing{" "}
              <strong style={{ color: BRAND.purple }}>Essentials</strong>, building{" "}
              <strong style={{ color: BRAND.purple }}>Stability</strong>, enabling{" "}
              <strong style={{ color: BRAND.purple }}>Development</strong>, and creating{" "}
              <strong style={{ color: BRAND.black }}>Sustainability</strong> so every recipient
              becomes a contributor.
            </motion.p>

            {/* Project pills */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.65, delay: 0.3, ease: "easeOut" }}
              className="flex flex-wrap gap-2 mb-10"
            >
              {projects.map((item, i) => (
                <motion.span
                  key={item.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.35, delay: 0.38 + i * 0.07 }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] sm:text-xs font-semibold cursor-pointer select-none"
                  style={{
                    backgroundColor: `${BRAND.purple}10`,
                    color: BRAND.purple,
                    border: `1px solid ${BRAND.purple}28`,
                  }}
                  whileHover={{
                    scale: 1.1,
                    backgroundColor: BRAND.purple,
                    color: BRAND.white,
                    border: `1px solid ${BRAND.purple}`,
                  }}
                  whileTap={{ scale: 0.95 }}
                >
                  {item.icon}
                  {item.label}
                </motion.span>
              ))}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.65, delay: 0.45, ease: "easeOut" }}
              className="flex flex-wrap gap-4"
            >
              <motion.button
                whileHover={{
                  scale: 1.04,
                  boxShadow: `0 10px 34px ${BRAND.purple}55`,
                }}
                whileTap={{ scale: 0.96 }}
                className="flex items-center gap-2 px-7 py-3.5 rounded-full text-sm font-bold cursor-pointer border-0 outline-none"
                style={{ backgroundColor: BRAND.purple, color: BRAND.white }}
              >
                Explore Ecosystem <ArrowRight size={16} />
              </motion.button>

              <motion.button
                whileHover={{
                  scale: 1.04,
                  boxShadow: `0 10px 34px ${BRAND.yellow}77`,
                }}
                whileTap={{ scale: 0.96 }}
                className="flex items-center gap-2 px-7 py-3.5 rounded-full text-sm font-bold cursor-pointer border-0 outline-none"
                style={{ backgroundColor: BRAND.yellow, color: BRAND.black }}
              >
                Learn More <ChevronRight size={16} />
              </motion.button>
            </motion.div>

            {/* Phase mini-steps */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex items-center gap-3 mt-10"
            >
              {[
                { num: "1", name: "Essentials", c: BRAND.purple },
                { num: "2", name: "Stability", c: BRAND.yellow },
                { num: "3", name: "Development", c: BRAND.purple },
                { num: "4", name: "Sustainability", c: BRAND.black },
              ].map((ph, i) => (
                <div key={ph.num} className="flex items-center gap-2">
                  <div className="flex flex-col items-center gap-0.5">
                    <div
                      className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-black"
                      style={{
                        backgroundColor: ph.c,
                        color: ph.c === BRAND.yellow ? BRAND.black : BRAND.white,
                      }}
                    >
                      {ph.num}
                    </div>
                    <span
                      className="text-[8px] font-semibold hidden sm:block text-center leading-tight"
                      style={{ color: `${BRAND.black}70`, maxWidth: 48 }}
                    >
                      {ph.name}
                    </span>
                  </div>
                  {i < 3 && (
                    <motion.div
                      className="h-[2px] flex-1 rounded-full"
                      style={{ backgroundColor: BRAND.purple, opacity: 0.2, minWidth: 12 }}
                      animate={{ opacity: [0.2, 0.6, 0.2] }}
                      transition={{ duration: 1.8, repeat: Infinity, delay: i * 0.4 }}
                    />
                  )}
                </div>
              ))}
            </motion.div>
          </div>

          {/* ══ RIGHT — Ecosystem Diagram ══ */}
          <div className="flex-1 w-full flex items-center justify-center lg:justify-end">
            <div className="w-full" style={{ maxWidth: 560 }}>
              <EcosystemDiagram isInView={isInView} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
